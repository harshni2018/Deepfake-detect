import React, { useState, useRef } from 'react';
import { Upload, Video, Mic, AlertTriangle, CheckCircle, XCircle, Info, Play, Pause } from 'lucide-react';

const DeepfakeDetector = () => {
  const [activeTab, setActiveTab] = useState('video');
  const [file, setFile] = useState(null);
  const [analyzing, setAnalyzing] = useState(false);
  const [result, setResult] = useState(null);
  const [videoUrl, setVideoUrl] = useState(null);
  const [isPlaying, setIsPlaying] = useState(false);
  const videoRef = useRef(null);
  const fileInputRef = useRef(null);

  const analyzeFile = async () => {
    if (!file) return;

    setAnalyzing(true);
    setResult(null);

    // Simulate analysis with realistic timing
    await new Promise(resolve => setTimeout(resolve, 3000));

    // FIXED: Random detection - 50% chance of deepfake, 50% chance of authentic
    const randomValue = Math.random();
    const isDeepfake = randomValue > 0.5;  // 50/50 chance
    const confidence = isDeepfake 
      ? Math.floor(Math.random() * 25) + 65  // 65-90% for deepfakes
      : Math.floor(Math.random() * 25) + 75; // 75-100% for authentic
    
    const indicators = [
      {
        name: 'Facial Consistency',
        status: isDeepfake ? 'suspicious' : 'normal',
        description: isDeepfake 
          ? 'Inconsistent facial landmarks detected across frames'
          : 'Facial features maintain natural consistency',
        confidence: isDeepfake 
          ? Math.floor(Math.random() * 20) + 70  // 70-90
          : Math.floor(Math.random() * 15) + 85  // 85-100
      },
      {
        name: 'Blinking Pattern',
        status: isDeepfake ? 'suspicious' : 'normal',
        description: isDeepfake
          ? 'Abnormal blinking frequency and duration'
          : 'Natural blinking patterns observed',
        confidence: isDeepfake 
          ? Math.floor(Math.random() * 20) + 70
          : Math.floor(Math.random() * 15) + 85
      },
      {
        name: 'Lighting Analysis',
        status: isDeepfake ? 'suspicious' : 'normal',
        description: isDeepfake
          ? 'Inconsistent lighting angles on facial features'
          : 'Lighting remains consistent with environment',
        confidence: isDeepfake 
          ? Math.floor(Math.random() * 20) + 65
          : Math.floor(Math.random() * 15) + 80
      },
      {
        name: 'Audio-Visual Sync',
        status: isDeepfake ? 'suspicious' : 'normal',
        description: isDeepfake
          ? 'Lip movements don\'t perfectly match audio patterns'
          : 'Speech synchronization appears natural',
        confidence: isDeepfake 
          ? Math.floor(Math.random() * 20) + 68
          : Math.floor(Math.random() * 15) + 88
      },
      {
        name: 'Compression Artifacts',
        status: isDeepfake ? 'suspicious' : 'normal',
        description: isDeepfake
          ? 'Unusual compression patterns suggest manipulation'
          : 'Normal compression artifacts for this format',
        confidence: isDeepfake 
          ? Math.floor(Math.random() * 20) + 60
          : Math.floor(Math.random() * 15) + 82
      }
    ];

    setResult({
      isDeepfake,
      confidence: confidence,
      indicators,
      recommendation: isDeepfake
        ? 'This content shows multiple signs of manipulation. Verify through independent sources before sharing.'
        : 'No significant manipulation detected. Content appears authentic based on analysis.'
    });

    setAnalyzing(false);
  };

  const handleFileChange = (e) => {
    const selectedFile = e.target.files[0];
    if (selectedFile) {
      setFile(selectedFile);
      setResult(null);
      
      if (activeTab === 'video') {
        const url = URL.createObjectURL(selectedFile);
        setVideoUrl(url);
      }
    }
  };

  const togglePlayPause = () => {
    if (videoRef.current) {
      if (isPlaying) {
        videoRef.current.pause();
      } else {
        videoRef.current.play();
      }
      setIsPlaying(!isPlaying);
    }
  };

  const getStatusColor = (status) => {
    switch (status) {
      case 'suspicious': return 'text-red-600';
      case 'normal': return 'text-green-600';
      default: return 'text-gray-600';
    }
  };

  const getStatusIcon = (status) => {
    switch (status) {
      case 'suspicious': return <XCircle className="w-5 h-5" />;
      case 'normal': return <CheckCircle className="w-5 h-5" />;
      default: return <Info className="w-5 h-5" />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 p-6">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold text-white mb-3">Deepfake Detection System</h1>
          <p className="text-purple-200 text-lg">Advanced AI-powered analysis for video and audio authenticity</p>
        </div>

        {/* Main Card */}
        <div className="bg-white rounded-2xl shadow-2xl overflow-hidden">
          {/* Tabs */}
          <div className="flex border-b border-gray-200">
            <button
              onClick={() => setActiveTab('video')}
              className={`flex-1 py-4 px-6 font-semibold transition-colors ${
                activeTab === 'video'
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Video className="w-5 h-5 inline mr-2" />
              Video Analysis
            </button>
            <button
              onClick={() => setActiveTab('audio')}
              className={`flex-1 py-4 px-6 font-semibold transition-colors ${
                activeTab === 'audio'
                  ? 'bg-purple-600 text-white'
                  : 'bg-gray-50 text-gray-600 hover:bg-gray-100'
              }`}
            >
              <Mic className="w-5 h-5 inline mr-2" />
              Audio Analysis
            </button>
          </div>

          <div className="p-8">
            {/* Upload Section */}
            <div className="mb-8">
              <input
                ref={fileInputRef}
                type="file"
                accept={activeTab === 'video' ? 'video/*' : 'audio/*'}
                onChange={handleFileChange}
                className="hidden"
              />
              
              {!file ? (
                <div
                  onClick={() => fileInputRef.current?.click()}
                  className="border-3 border-dashed border-purple-300 rounded-xl p-12 text-center cursor-pointer hover:border-purple-500 hover:bg-purple-50 transition-all"
                >
                  <Upload className="w-16 h-16 mx-auto mb-4 text-purple-600" />
                  <p className="text-xl font-semibold text-gray-700 mb-2">
                    Upload {activeTab === 'video' ? 'Video' : 'Audio'} File
                  </p>
                  <p className="text-gray-500">
                    Click to browse or drag and drop your file here
                  </p>
                </div>
              ) : (
                <div className="space-y-4">
                  <div className="bg-purple-50 rounded-xl p-6 border border-purple-200">
                    <div className="flex items-center justify-between mb-4">
                      <div>
                        <p className="font-semibold text-gray-800">{file.name}</p>
                        <p className="text-sm text-gray-500">
                          {(file.size / 1024 / 1024).toFixed(2)} MB
                        </p>
                      </div>
                      <button
                        onClick={() => {
                          setFile(null);
                          setResult(null);
                          setVideoUrl(null);
                        }}
                        className="text-red-600 hover:text-red-800 font-semibold"
                      >
                        Remove
                      </button>
                    </div>

                    {/* Video Preview */}
                    {activeTab === 'video' && videoUrl && (
                      <div className="relative bg-black rounded-lg overflow-hidden">
                        <video
                          ref={videoRef}
                          src={videoUrl}
                          className="w-full max-h-96 object-contain"
                          onPlay={() => setIsPlaying(true)}
                          onPause={() => setIsPlaying(false)}
                        />
                        <button
                          onClick={togglePlayPause}
                          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2 bg-white bg-opacity-80 hover:bg-opacity-100 rounded-full p-4 transition-all"
                        >
                          {isPlaying ? (
                            <Pause className="w-8 h-8 text-gray-800" />
                          ) : (
                            <Play className="w-8 h-8 text-gray-800" />
                          )}
                        </button>
                      </div>
                    )}
                  </div>

                  <button
                    onClick={analyzeFile}
                    disabled={analyzing}
                    className={`w-full py-4 px-6 rounded-xl font-bold text-lg transition-all ${
                      analyzing
                        ? 'bg-gray-400 cursor-not-allowed'
                        : 'bg-gradient-to-r from-purple-600 to-pink-600 hover:from-purple-700 hover:to-pink-700 text-white shadow-lg'
                    }`}
                  >
                    {analyzing ? (
                      <span className="flex items-center justify-center">
                        <svg className="animate-spin h-6 w-6 mr-3" viewBox="0 0 24 24">
                          <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" fill="none" />
                          <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                        </svg>
                        Analyzing...
                      </span>
                    ) : (
                      'Analyze for Deepfakes'
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Results Section */}
            {result && (
              <div className="space-y-6 animate-fadeIn">
                {/* Overall Result */}
                <div className={`rounded-xl p-6 border-2 ${
                  result.isDeepfake
                    ? 'bg-red-50 border-red-300'
                    : 'bg-green-50 border-green-300'
                }`}>
                  <div className="flex items-start gap-4">
                    <div className={`p-3 rounded-full ${
                      result.isDeepfake ? 'bg-red-200' : 'bg-green-200'
                    }`}>
                      {result.isDeepfake ? (
                        <AlertTriangle className="w-8 h-8 text-red-700" />
                      ) : (
                        <CheckCircle className="w-8 h-8 text-green-700" />
                      )}
                    </div>
                    <div className="flex-1">
                      <h3 className={`text-2xl font-bold mb-2 ${
                        result.isDeepfake ? 'text-red-900' : 'text-green-900'
                      }`}>
                        {result.isDeepfake ? 'Potential Deepfake Detected' : 'Content Appears Authentic'}
                      </h3>
                      <p className={`text-lg mb-3 ${
                        result.isDeepfake ? 'text-red-800' : 'text-green-800'
                      }`}>
                        Confidence: {result.confidence}%
                      </p>
                      <p className={result.isDeepfake ? 'text-red-700' : 'text-green-700'}>
                        {result.recommendation}
                      </p>
                    </div>
                  </div>
                </div>

                {/* Detailed Indicators */}
                <div>
                  <h4 className="text-xl font-bold text-gray-800 mb-4">Analysis Details</h4>
                  <div className="space-y-3">
                    {result.indicators.map((indicator, index) => (
                      <div
                        key={index}
                        className="bg-gray-50 rounded-lg p-4 border border-gray-200"
                      >
                        <div className="flex items-center justify-between mb-2">
                          <div className="flex items-center gap-2">
                            <span className={getStatusColor(indicator.status)}>
                              {getStatusIcon(indicator.status)}
                            </span>
                            <span className="font-semibold text-gray-800">
                              {indicator.name}
                            </span>
                          </div>
                          <span className={`font-bold ${getStatusColor(indicator.status)}`}>
                            {indicator.confidence}%
                          </span>
                        </div>
                        <p className="text-gray-600 text-sm ml-7">
                          {indicator.description}
                        </p>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Additional Info */}
                <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                  <div className="flex gap-3">
                    <Info className="w-5 h-5 text-blue-600 flex-shrink-0 mt-0.5" />
                    <div className="text-sm text-blue-800">
                      <p className="font-semibold mb-1">How to verify further:</p>
                      <ul className="list-disc list-inside space-y-1">
                        <li>Check multiple independent sources</li>
                        <li>Look for the original source of the content</li>
                        <li>Examine metadata and publication details</li>
                        <li>Consult fact-checking organizations</li>
                      </ul>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Info Section */}
        <div className="mt-8 bg-white bg-opacity-10 backdrop-blur-lg rounded-xl p-6 text-white">
          <h3 className="text-xl font-bold mb-3">About This Tool</h3>
          <p className="mb-3">
            This deepfake detection system analyzes video and audio content for signs of AI-generated manipulation using multiple detection techniques including facial analysis, audio-visual synchronization, and artifact detection.
          </p>
          <p className="text-purple-200 text-sm">
            Note: This is a demonstration tool. Real-world deepfake detection requires sophisticated machine learning models trained on extensive datasets and should be used as part of a comprehensive verification process.
          </p>
        </div>
      </div>
    </div>
  );
};

export default DeepfakeDetector;